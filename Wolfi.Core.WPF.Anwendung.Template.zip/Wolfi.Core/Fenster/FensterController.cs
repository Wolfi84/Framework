﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Fenster
{
    internal class FensterXmlController : Generisch.XmlController<Core.Fenster.FensterListe>
    {

    }

}
